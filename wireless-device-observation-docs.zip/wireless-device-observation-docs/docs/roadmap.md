# Project Roadmap

## Purpose

This roadmap breaks the project into milestones that can be built, tested, documented, and committed independently.

The sequence keeps the Raspberry Pi useful before AWS is introduced and makes it easier to isolate problems between the radio, collector, local database, uploader, application services, and cloud storage.

# Milestone 1 - Wireless Observation Prototype

**Status: Complete**

## Goal

Prove that the Raspberry Pi can use the AWUS036ACM to passively observe nearby Wi-Fi activity across selected 2.4 GHz and 5 GHz channels.

## Completed Work

```text
[✓] Raspberry Pi OS configured
[✓] Required wireless packages installed
[✓] AWUS036ACM detected by Linux
[✓] Monitor mode support verified
[✓] wlan1 removed from NetworkManager control
[✓] mon24 monitor interface created
[✓] Fixed-channel capture tested
[✓] 2.4 GHz channel switching verified
[✓] 5 GHz channel switching verified
[✓] Dual-band channel hopping working
[✓] Source MAC extracted with TShark
[✓] RSSI extracted with TShark
[✓] Frequency extracted with TShark
[✓] Detailed Pi setup documented
```

## Acceptance Result

The scanner can display live observations containing timestamp, source MAC, RSSI, and frequency while the Alfa hops across the configured channels.

# Milestone 2 - Python Collector

**Status: Next**

## Goal

Replace the raw terminal stream with a Python application that creates structured observation summaries.

## Work Items

```text
[ ] Start TShark from Python
[ ] Read line-buffered output
[ ] Validate field counts and values
[ ] Normalize timestamps
[ ] Normalize MAC formatting
[ ] Convert frequency to channel
[ ] Convert channel to Wi-Fi band
[ ] Detect locally administered addresses
[ ] Track first seen and last seen
[ ] Count repeated observations
[ ] Calculate latest, minimum, maximum, and average RSSI
[ ] Display a readable live summary
[ ] Add unit tests for parsing and classification
```

## Acceptance Criteria

- The collector runs continuously without manually reading TShark output.
- Malformed lines do not crash the process.
- Repeated MAC observations update one summary record.
- Frequency mapping and address classification are covered by tests.
- The terminal can display a live device summary.

# Milestone 3 - SQLite Persistence

**Status: Planned**

## Goal

Persist observation summaries and upload batches locally.

## Work Items

```text
[ ] Design SQLite schema
[ ] Create database initialization logic
[ ] Upsert observation summaries
[ ] Create upload batch table
[ ] Track pending, attempted, and acknowledged batches
[ ] Add database indexes
[ ] Add retention or cleanup rules
[ ] Test restart recovery
```

## Acceptance Criteria

- Restarting the collector does not lose the previous observation state.
- Pending uploads survive a reboot.
- Database operations are tested.
- The database does not grow without a documented retention strategy.

# Milestone 4 - Persistent Pi Services

**Status: Planned**

## Goal

Make the scanner start automatically and recover from failures.

## Work Items

```text
[ ] Create monitor-setup.sh
[ ] Create channel-hopper.sh
[ ] Create systemd monitor service
[ ] Create systemd hopper service
[ ] Create systemd collector service
[ ] Add service dependencies and startup ordering
[ ] Add restart policies
[ ] Send logs to the system journal
[ ] Test a complete Pi reboot
[ ] Test adapter disconnect and reconnect behavior
```

## Acceptance Criteria

- The Pi starts scanning after a reboot without manual commands.
- The collector restarts after an unexpected failure.
- Service logs are available through `journalctl`.
- `wlan0` remains available for normal connectivity.

# Milestone 5 - Local AWS Uploader

**Status: Planned**

## Goal

Send acknowledged observation batches to an HTTPS endpoint without losing data during temporary failures.

## Work Items

```text
[ ] Define JSON batch format
[ ] Build uploader HTTP client
[ ] Add scanner identification
[ ] Add authentication header support
[ ] Add request timeout
[ ] Add retry and backoff behavior
[ ] Keep batches until acknowledged
[ ] Record upload errors locally
[ ] Add integration tests against a local mock API
```

## Acceptance Criteria

- A successful request marks the batch as uploaded.
- A failed request leaves the batch pending.
- Temporary network loss does not lose observations.
- Secrets are not stored in the repository.

# Milestone 6 - AWS Historical Storage

**Status: Planned**

## Goal

Create the first working AWS ingestion path from the API to S3.

## Work Items

```text
[ ] Create S3 bucket design
[ ] Define S3 key structure
[ ] Implement device-ingest Lambda
[ ] Validate observation batches
[ ] Write normalized JSON objects to S3
[ ] Add least-privilege IAM permissions
[ ] Add Lambda logs
[ ] Add unit and integration tests
```

## Acceptance Criteria

- A valid observation batch creates one traceable S3 object.
- The object path includes enough information to locate data by scanner and time.
- Invalid input is rejected and logged.
- The Lambda cannot access unrelated resources.

# Milestone 7 - DynamoDB Metadata

**Status: Planned**

## Goal

Maintain current searchable device state in DynamoDB.

## Work Items

```text
[ ] Define table keys
[ ] Define current-state record format
[ ] Define history-index strategy
[ ] Implement metadata-update Lambda
[ ] Maintain first seen and last seen
[ ] Increment observation counts
[ ] Update RSSI summaries
[ ] Store channel, band, and address classification
[ ] Apply five-minute observation logic
[ ] Test concurrent updates and idempotency
```

## Acceptance Criteria

- New addresses create records.
- Existing addresses update without losing first-seen data.
- Replayed batches do not create incorrect counts or duplicate state.
- Search keys support the planned API queries.

# Milestone 8 - Containerized Ingestion API

**Status: Planned**

## Goal

Expose a validated ingestion endpoint through a containerized service.

## Work Items

```text
[ ] Define POST /observations contract
[ ] Build ingestion-api
[ ] Validate authentication and request body
[ ] Invoke device-ingest Lambda
[ ] Invoke metadata-update Lambda
[ ] Return consistent success and error responses
[ ] Add application logging
[ ] Build Docker image
[ ] Add unit and container tests
```

## Acceptance Criteria

- The container runs locally.
- Valid batches reach both ingestion Lambdas.
- Invalid batches receive clear client errors.
- Lambda failures produce clear server errors and logs.

# Milestone 9 - Search and History API

**Status: Planned**

## Goal

Provide current device lookup and historical search.

## Work Items

```text
[ ] Define GET /devices
[ ] Define GET /devices/{id}
[ ] Define GET /history/{id}
[ ] Implement device-search Lambda
[ ] Implement device-history Lambda
[ ] Build search-api container
[ ] Add filtering and pagination
[ ] Add API response models
[ ] Add tests
```

## Acceptance Criteria

- Current device records are returned from DynamoDB.
- Historical summaries are returned for a device identifier.
- Detailed historical data can be retrieved from S3 when needed.
- Large result sets use pagination.

# Milestone 10 - Two-Instance AWS Deployment

**Status: Planned**

## Goal

Deploy the two service containers across two EC2 instances behind one Application Load Balancer.

## Work Items

```text
[ ] Create VPC and subnet design
[ ] Create security groups
[ ] Launch two EC2 instances
[ ] Run ingestion-api on both EC2 instances
[ ] Run search-api on both EC2 instances
[ ] Create ingestion target group
[ ] Create search target group
[ ] Create ALB listener rules
[ ] Add health-check endpoints
[ ] Test one-instance failure
```

## Acceptance Criteria

- Both EC2 instances run both containers.
- `/observations*` routes only to ingestion containers.
- `/devices*` and `/history*` route only to search containers.
- Stopping one EC2 instance does not make either API unavailable.
- Unhealthy containers are removed from rotation.

# Milestone 11 - Monitoring and Operational Testing

**Status: Planned**

## Goal

Make the application observable and test the main failure cases.

## Work Items

```text
[ ] Centralize container logs
[ ] Enable Lambda logging
[ ] Create ALB and target-health alarms
[ ] Create Lambda error alarms
[ ] Create ingestion failure alarm
[ ] Create search failure alarm
[ ] Build CloudWatch dashboard
[ ] Test AWS outage behavior from the Pi
[ ] Test network interruption
[ ] Test EC2 failure
[ ] Test Lambda failure
[ ] Test malformed batch handling
```

## Acceptance Criteria

- A failure can be located using Pi logs and CloudWatch.
- The main failure scenarios are documented.
- Alarms trigger for unhealthy targets and repeated function failures.
- The Pi resumes uploading after a temporary outage.

# Milestone 12 - Final Documentation and Demonstration

**Status: Planned**

## Goal

Make the repository understandable to someone who did not build the project.

## Work Items

```text
[ ] Update root README
[ ] Complete AWS setup guide
[ ] Complete API documentation
[ ] Complete testing document
[ ] Add final architecture diagrams
[ ] Add sanitized example output
[ ] Document design decisions and limitations
[ ] Add deployment and teardown instructions
[ ] Record a short demonstration
```

## Acceptance Criteria

- A reviewer can understand what is implemented and what remains planned.
- The repository contains no credentials or private capture data.
- Setup and teardown instructions are complete.
- Architecture diagrams match the deployed environment.
- The demo shows data moving from the Pi through AWS and back through the search API.
