# Wireless Device Observation Platform - Project README

## Introduction

This project combines a Raspberry Pi-based wireless observation sensor with an AWS application and storage layer.

The Raspberry Pi sits inside my home and passively observes nearby Wi-Fi activity. The nearby devices do not need to connect to the Pi, join my home network, or communicate directly with the application. The dedicated Wi-Fi adapter listens for observable IEEE 802.11 frames on the channel it is currently monitoring.

The current prototype collects:

- Observation time
- Source MAC address
- Received signal strength, or RSSI
- Wireless frequency
- Wi-Fi channel and band

The Raspberry Pi side is working through TShark. The next stage is to build a Python collector that turns repeated frame-level observations into structured records and stores them locally before sending them to AWS.

## Project Goal

My goal is to build one complete system that demonstrates both physical networking and cloud architecture.

```text
Nearby wireless activity
        |
        v
Raspberry Pi edge sensor
        |
        v
Local observation processing
        |
        v
AWS ingestion, storage, search, and monitoring
```

The project is intentionally broader than a basic packet-capture exercise. The finished platform should demonstrate practical experience with:

- Linux wireless interfaces
- IEEE 802.11 monitor mode
- Channel hopping
- Python processing
- SQLite
- Docker
- REST APIs
- Amazon EC2
- Elastic Load Balancing
- AWS Lambda
- Amazon DynamoDB
- Amazon S3
- Amazon CloudWatch

## Why I Chose This Design

I wanted the AWS portion of the project to solve a real data problem instead of processing static sample records.

The wireless environment creates continuous, imperfect, and repetitive data. That gives me realistic engineering decisions to work through:

- A single radio cannot listen to every channel at once.
- One device may appear under multiple randomized MAC addresses.
- One address may be observed hundreds of times in a short period.
- Network or AWS connectivity may be temporarily unavailable.
- Raw historical data and current searchable state have different storage needs.
- The application should remain available if one EC2 instance fails.

These constraints give each project component a clear purpose.

## Current Implementation

The currently implemented hardware and software are:

```text
Raspberry Pi 4B
Raspberry Pi OS
Alfa AWUS036ACM
Linux monitor mode
Dual-band channel hopping
TShark metadata extraction
```

The Pi uses two separate wireless roles.

```text
phy0 / wlan0
`-- Normal Pi Wi-Fi connection and Internet access

phy3 / AWUS036ACM
|-- wlan1: normal managed interface, left unmanaged and down
`-- mon24: monitor-mode interface used for scanning
```

The current implemented pipeline is:

```text
Nearby Wi-Fi activity
        |
        v
AWUS036ACM
        |
        v
mon24 monitor interface
        |
        v
Channel hopper
        |
        v
TShark
        |
        v
Timestamp | Source MAC | RSSI | Frequency
```

This is the real endpoint of the running project today. The Python, SQLite, container, Lambda, and AWS sections in this document describe the planned architecture.

## Channel Strategy

The AWUS036ACM contains one physical Wi-Fi radio. It can only listen to one channel at a time.

The current hopper rotates through:

```text
2.4 GHz: 1, 6, 11
5 GHz:   36, 40, 44, 48, 149, 153, 157, 161
```

The current dwell time is one second per channel.

This design gives the first version coverage across both bands without buying a second adapter. The tradeoff is that the scanner can miss a short transmission that occurs on a different channel while the radio is tuned elsewhere.

That tradeoff is acceptable for the first version because the project is focused on building an observation history over time rather than guaranteeing full packet capture.

## Observation Scope

The project is focused on metadata rather than packet content.

The current TShark command extracts:

```text
Timestamp
Source MAC
RSSI
Frequency
```

The project does not require packet payloads for its intended purpose.

This keeps the edge collector focused on device-presence observations rather than communication reconstruction.

## MAC Address Identity Model

A MAC address is not treated as a permanent physical identity.

Modern devices may use:

- Randomized MAC addresses
- Private per-network addresses
- Locally administered addresses
- Different identifiers across Wi-Fi and Bluetooth radios

The initial data model therefore separates the concepts of an observed address and a logical device.

```text
Observed MAC address
        |
        v
Wireless observation
        |
        v
Optional logical-device association
```

The first version will not automatically merge multiple addresses into one physical device.

The collector can identify whether a MAC appears locally administered, but that field will be supporting metadata rather than proof that an address is randomized.

## Next Local Architecture

The next milestone is the Python collector.

```text
AWUS036ACM
    |
    v
Monitor mode
    |
    v
Channel hopper
    |
    v
TShark
    |
    v
Python collector
    |
    |-- Parse fields
    |-- Validate records
    |-- Normalize timestamps and MAC format
    |-- Convert frequency to channel and band
    |-- Identify locally administered addresses
    |-- Deduplicate repeated observations
    |-- Maintain first seen and last seen
    |-- Count observations
    `-- Aggregate RSSI
    |
    v
SQLite
    |
    v
Upload queue
```

The local database gives the Pi a durable buffer if the network or AWS endpoint is temporarily unavailable.

Planned observation fields include:

```text
scanner_id
observed_mac
first_seen
last_seen
observation_count
latest_rssi
minimum_rssi
maximum_rssi
average_rssi
frequency
channel
band
locally_administered
upload_status
```

## Planned AWS Architecture

The AWS application layer uses two EC2 instances. Each instance runs the same two container images:

```text
EC2 Instance 1
|-- ingestion-api
`-- search-api

EC2 Instance 2
|-- ingestion-api
`-- search-api
```

This creates four running containers while keeping the application design focused on two clear service roles.

The Application Load Balancer uses path-based routing:

```text
POST /observations*  --> ingestion-api target group
GET  /devices*       --> search-api target group
GET  /history*       --> search-api target group
```

Each target group contains the matching container on both EC2 instances.

```text
Application Load Balancer
        |
        |-- ingestion-api target group
        |   |-- EC2 #1 / ingestion-api
        |   `-- EC2 #2 / ingestion-api
        |
        `-- search-api target group
            |-- EC2 #1 / search-api
            `-- EC2 #2 / search-api
```

This lets the application continue serving either type of request if one EC2 instance becomes unavailable.

## Container Responsibilities

### ingestion-api

The ingestion service receives observation batches from the Raspberry Pi.

Planned responsibilities:

1. Receive an HTTPS request from the Pi.
2. Validate the scanner and request format.
3. Validate each observation record.
4. Invoke the `device-ingest` Lambda.
5. Invoke the `metadata-update` Lambda.
6. Return an ingestion result to the Pi.

Planned endpoint:

```http
POST /observations
```

### search-api

The search service handles device and history queries.

Planned responsibilities:

1. Validate the request.
2. Invoke `device-search` for current device state.
3. Invoke `device-history` for historical queries.
4. Return a consistent API response.

Planned endpoints:

```http
GET /devices
GET /devices/{id}
GET /history/{id}
```

## Lambda Responsibilities

### device-ingest

The `device-ingest` Lambda writes raw or normalized observation batches to Amazon S3.

S3 provides the historical record of what the scanner submitted.

### metadata-update

The `metadata-update` Lambda updates current searchable state in DynamoDB.

Planned responsibilities include:

- Creating records for newly observed addresses
- Maintaining first seen and last seen
- Incrementing observation counts
- Updating RSSI summaries
- Updating recent channel and band information
- Storing address classification fields
- Applying the project's five-minute observation logic

### device-search

The `device-search` Lambda queries current or searchable records in DynamoDB.

### device-history

The `device-history` Lambda queries history indexes in DynamoDB and retrieves detailed historical objects from S3 when needed.

## Storage Responsibilities

The project uses S3 and DynamoDB for different purposes.

### Amazon S3

```text
Raw or normalized historical observation batches
Long-term historical records
Detailed source data for later analysis
```

### Amazon DynamoDB

```text
Current searchable device state
First seen and last seen
Observation summaries
Address classification
History indexes
Fast API queries
```

The database should not replace the historical archive, and S3 should not be used as the main low-latency search database.

## Monitoring

Amazon CloudWatch will monitor the AWS portion of the project.

Planned monitoring includes:

- Application Load Balancer request and target health metrics
- EC2 system metrics
- Container application logs
- Lambda invocation logs
- Lambda errors and duration
- Ingestion failures
- Search failures
- Resource alarms

The Pi will also need local logging so I can distinguish edge-collection failures from AWS-side failures.

## Reliability Approach

The project is designed around several failure points.

### If AWS is unavailable

The Pi stores pending observations in SQLite and retries them later.

### If one EC2 instance fails

The matching containers on the second EC2 instance remain registered in the load balancer target groups.

### If a Lambda invocation fails

The application records the failure and returns an error that can be retried or investigated.

### If the Pi reboots

The future systemd services will recreate the monitor interface, restart channel hopping, and start the collector automatically.

## Privacy and Authorized Use

This project is intended for authorized experimentation in my own environment.

The collection scope is limited to radio metadata needed for the project. Packet payloads are not required.

The project also avoids claiming that an observed MAC address proves a person's identity or permanently identifies one physical device.

## Current Limitations

- One adapter can only monitor one channel at a time.
- Channel hopping can miss short transmissions.
- A device must transmit while the scanner is listening to the relevant channel.
- MAC randomization prevents reliable identity based on MAC alone.
- RSSI is not an exact distance measurement.
- The current scanner startup process is manual.
- The collector, database, uploader, containers, Lambdas, and AWS infrastructure are still planned work.

## Milestones

### Milestone 1 - Wireless observation prototype

Complete.

```text
[✓] Monitor-mode interface
[✓] Fixed-channel capture
[✓] 2.4 GHz scanning
[✓] 5 GHz scanning
[✓] Dual-band channel hopping
[✓] MAC, RSSI, and frequency extraction
```

### Milestone 2 - Python collector

Next.

```text
[ ] Stream TShark into Python
[ ] Normalize observations
[ ] Deduplicate records
[ ] Aggregate RSSI
[ ] Classify address type
[ ] Display a live summary
```

### Milestone 3 - Local persistence and automation

```text
[ ] SQLite schema
[ ] Upload queue
[ ] Retry logic
[ ] systemd monitor setup
[ ] systemd channel hopper
[ ] systemd collector service
```

### Milestone 4 - AWS ingestion

```text
[ ] Containerize ingestion-api
[ ] Build device-ingest Lambda
[ ] Build metadata-update Lambda
[ ] Create S3 storage
[ ] Create DynamoDB tables
[ ] Deploy the first ingestion path
```

### Milestone 5 - Search and history

```text
[ ] Containerize search-api
[ ] Build device-search Lambda
[ ] Build device-history Lambda
[ ] Add device and history endpoints
```

### Milestone 6 - Availability and monitoring

```text
[ ] Two EC2 instances
[ ] Both containers on each EC2 instance
[ ] Application Load Balancer
[ ] Path-based target groups
[ ] CloudWatch logs and alarms
[ ] Failure and recovery testing
```

## Success Criteria

I will consider the first complete version successful when:

1. The Pi starts the scanner automatically after a reboot.
2. The Python collector creates structured observations from TShark.
3. SQLite buffers observations during a network interruption.
4. The Pi sends summarized batches to the ingestion API.
5. S3 stores the historical batches.
6. DynamoDB maintains searchable current state.
7. The search API returns current and historical data.
8. The application remains available when one EC2 instance is stopped.
9. CloudWatch provides enough information to troubleshoot the AWS path.
10. The repository documents the design, setup, tests, and limitations clearly.
